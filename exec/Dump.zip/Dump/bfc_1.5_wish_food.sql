-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 3.39.6.158    Database: bfc_1.5
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wish_food`
--

DROP TABLE IF EXISTS `wish_food`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wish_food` (
  `wish_food_id` bigint NOT NULL AUTO_INCREMENT,
  `keyword` varchar(10) NOT NULL,
  `full_course_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`wish_food_id`),
  KEY `fk_wish_food_fullcourse1_idx` (`full_course_id`),
  CONSTRAINT `fk_wish_food_fullcourse1` FOREIGN KEY (`full_course_id`) REFERENCES `full_course` (`full_course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wish_food`
--

LOCK TABLES `wish_food` WRITE;
/*!40000 ALTER TABLE `wish_food` DISABLE KEYS */;
INSERT INTO `wish_food` VALUES (5,'밀면',2),(7,'고기',4),(8,'고기',4),(9,'고기',4),(10,'고기',4),(14,'술집',7),(15,'고기',7),(16,'이자카야',7),(17,'카페',7),(18,'초밥/스시',9),(19,'회',10),(20,'초밥/스시',10),(21,'밀면',11),(22,'카페',11),(23,'이자카야',12),(24,'제과점',12),(25,'밀면',13),(26,'카페',13),(27,'양식',14),(28,'밀면',14),(29,'양식',15),(30,'회',15),(31,'밀면',15),(32,'분식',16),(33,'기타',16),(34,'이자카야',18),(35,'곱창',18),(36,'초밥/스시',18),(37,'제과점',19),(38,'분식',19),(39,'밀면',20),(40,'회',20),(41,'술집',20),(42,'일식',20),(43,'해물',20),(44,'초밥/스시',20),(45,'일식',21),(46,'치킨',21),(47,'양식',21),(48,'한식',22),(49,'밀면',22),(50,'이자카야',23),(51,'제과점',23),(52,'곱창',23),(53,'분식',23),(57,'이자카야',25),(58,'고기',25),(59,'초밥/스시',25),(60,'중식',26),(61,'분식',26),(62,'기타',26),(63,'카페',27),(64,'밀면',28),(65,'일식',28),(66,'술집',31),(67,'제과점',33),(68,'회',33),(69,'제과점',34),(70,'회',34),(71,'제과점',35),(72,'곱창',35);
/*!40000 ALTER TABLE `wish_food` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 11:56:32
