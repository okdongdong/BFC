-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 3.39.6.158    Database: bfc_1.5
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wish_place`
--

DROP TABLE IF EXISTS `wish_place`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wish_place` (
  `wish_place_id` bigint NOT NULL AUTO_INCREMENT,
  `keyword` varchar(10) NOT NULL,
  `full_course_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`wish_place_id`),
  KEY `fk_wish_place_fullcourse1_idx` (`full_course_id`),
  CONSTRAINT `fk_wish_place_fullcourse1` FOREIGN KEY (`full_course_id`) REFERENCES `full_course` (`full_course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wish_place`
--

LOCK TABLES `wish_place` WRITE;
/*!40000 ALTER TABLE `wish_place` DISABLE KEYS */;
INSERT INTO `wish_place` VALUES (5,'산책로',2),(10,'해변',7),(11,'카페',7),(12,'산림',9),(13,'해변',9),(14,'카페',9),(15,'해변',10),(16,'산림',11),(17,'종교적인 장소',11),(18,'종교적인 장소',12),(19,'해변',12),(20,'카페',12),(21,'종교적인 장소',13),(22,'해변',13),(23,'종교적인 장소',14),(24,'해변',14),(25,'종교적인 장소',15),(26,'역사박물관',15),(27,'아트갤러리',15),(28,'공원',16),(29,'산림',16),(30,'역사박물관',18),(31,'박물관',18),(32,'전망대',18),(33,'카페',19),(34,'역사박물관',19),(35,'섬',19),(36,'섬',20),(37,'해변',20),(38,'산책로',20),(39,'종교적인 장소',21),(40,'해변',21),(41,'카페',21),(42,'섬',22),(43,'전망대',22),(44,'역사박물관',23),(45,'카페',23),(46,'박물관',23),(51,'종교적인 장소',25),(52,'해변',25),(53,'산책로',25),(54,'해변',26),(55,'카페',26),(56,'역사박물관',26),(57,'산림',27),(58,'산책로',27),(59,'섬',27),(60,'해변',28),(61,'카페',28),(62,'박물관',28),(63,'섬',30),(64,'카페',31),(65,'즐길거리',31),(66,'해변',33),(67,'카페',33),(68,'해변',34),(69,'카페',34),(70,'카페',35),(71,'역사박물관',35),(72,'박물관',35);
/*!40000 ALTER TABLE `wish_place` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 11:56:14
